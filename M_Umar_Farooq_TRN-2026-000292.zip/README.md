# Sunday Project — Data Quality, Insights & CSV Operations

**Student Name:** M. Umar Farooq  
**Training ID:** TRN-2026-000292

## GitHub Repository
https://github.com/farooq428/LMS-Assignments-Practices/

## Files included
- `Sunday_Project_Umar_Farooq.ipynb` — Complete runnable notebook containing Part A and Part B.
- `sales_raw.csv` — Original input dataset (kept unchanged).
- `cleaned_sales.csv` — Cleaned dataset with calculated revenue.
- `sales_updated.csv` — Part B output with 5% tax, updated Books prices, and the selected row removed.
- `revenue_by_region.png` — Part A chart showing revenue by region.
- `revenue_by_category.png` — Part A chart showing revenue by category.

## How to run
1. Extract the ZIP file.
2. Open the folder in Jupyter Notebook, JupyterLab, or upload the notebook and CSV file to Google Colab.
3. Keep `sales_raw.csv` in the same folder as the notebook.
4. Open `Sunday_Project_Umar_Farooq.ipynb`.
5. Run all cells from top to bottom. The notebook uses relative file paths and creates `cleaned_sales.csv`, both charts, and `sales_updated.csv`.

## Cleaning approach
The notebook standardizes region/category text, converts numeric fields, removes exact duplicates, and excludes rows with missing or invalid required values. It also excludes non-positive quantities/prices and unit prices above 1,000 as an unusually high value for this dataset. The original CSV is preserved.
